-- MySQL dump 10.13  Distrib 8.2.0, for macos13 (arm64)
--
-- Host: 192.168.31.10    Database: nacos
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `config_info`
--

DROP TABLE IF EXISTS `config_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL,
  `content` longtext COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  `app_name` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  `c_desc` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `c_use` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `effect` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `type` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `c_schema` text COLLATE utf8mb3_bin,
  `encrypted_data_key` text COLLATE utf8mb3_bin NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfo_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info`
--

LOCK TABLES `config_info` WRITE;
/*!40000 ALTER TABLE `config_info` DISABLE KEYS */;
INSERT INTO `config_info` (`id`, `data_id`, `group_id`, `content`, `md5`, `gmt_create`, `gmt_modified`, `src_user`, `src_ip`, `app_name`, `tenant_id`, `c_desc`, `c_use`, `effect`, `type`, `c_schema`, `encrypted_data_key`) VALUES (11,'common-prod.yml','DEFAULT_GROUP','spring:\n  cloud:\n    nacos:\n      discovery:\n        server-addr: 192.168.31.25:8848\n  data:\n    redis:\n      host: 192.168.31.25\n  output:\n    ansi:\n      enabled: always\n  logging:\n    pattern:\n      level=%5p [${spring.application.name:},%X{traceId:-},%X{spanId:-}]\n    level:\n      org:\n        springframework:\n          web:\n            servlet:\n              DispatcherServlet: DEBUG\n\nmanagement:\n  endpoints:\n    web:\n      exposure:\n        include: \"*\"\n  endpoint:\n    health:\n      show-details: ALWAYS\n  tracing:\n    sampling:\n      probability: 1.0\n  metrics:\n    distribution:\n      percentiles-histogram:\n        greeting: true\n        http:\n          server:\n            requests: true\ntest: 123            ','e2f88670abd381a8db91559cd52d5328','2024-02-22 15:38:13','2024-02-28 15:15:06','nacos','192.168.31.10','','prod','通用配置文件','','','yaml','',''),(12,'monitoring-service-prod.yml','DEFAULT_GROUP','server:\n  port: 7001\nspring:\n  application:\n    name: monitoring-service','91f2f45e350042e89bc098200bdacf38','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','服务监控模块配置文件',NULL,NULL,'yaml',NULL,''),(13,'system-service-prod.yml','DEFAULT_GROUP','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we_master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','bb7c8a85d065e39e25e05c85653fcb4a','2024-02-22 15:38:13','2024-02-28 16:27:08','nacos','192.168.31.10','','prod','系统管理微服务配置文件','','','yaml','',''),(14,'gateway-prod.yml','DEFAULT_GROUP','server:\n  port: 8080\nspring:\n  application:\n    name: gateway\n\n  cloud:\n    gateway:\n      default-filters:\n      - AddResponseHeader=X-Response-Default-Foo, Default-Bar\n      routes:\n      - id: validator-service\n        uri: lb://validator-service\n        predicates:\n        - Path=/validator/**\n        filters:\n        - StripPrefix=1\n      - id: system_service\n        uri: lb://system-service\n        predicates:\n          - Path=/system/**\n      - id: demo-service\n        uri: lb://demo-service\n        predicates:\n          - Path=/demo/**\n        filters:\n        - StripPrefix=1\n      - id: oauth2-service\n        uri: lb://oauth2-service\n        predicates:\n          - Path=/oauth2/**\n        #filters:\n        #- StripPrefix=1\n\n\n\nsecurity:\n    xss:\n      enabled: true','840361dd18bebe67a1c17104366bb55f','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','微服务网关配置文件',NULL,NULL,'yaml',NULL,''),(15,'demo-service-prod.yml','DEFAULT_GROUP','server:\n  port: 8083\nspring:\n  application:\n    name: demo-service\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n  #security:\n  #  oauth2:\n  #    resourceserver:\n  #      jwt:\n  #        issuer-uri: lb://oatuh2-server','48f5fd4d12023da34ea639221a306545','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','demo微服务配置文件',NULL,NULL,'yaml',NULL,''),(16,'sentinel-rules-gateway-prod','DEFAULT_GROUP','[\n    {\n        \"resource\": \"auth_service\",\n        \"count\": 1,\n        \"intervalSec\": 5,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    },\n	{\n        \"resource\": \"demo-service\",\n        \"count\": 1000,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    }\n]','1f626962e3574f6a56d1c8787634c30b','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','限流策略',NULL,NULL,'json',NULL,''),(17,'generator-service-prod.yml','DEFAULT_GROUP','server:\n  port: 9000\ngen:\n  author: wm\n  packageName: org.wm.generator\n  autoRemovePre: false\n  tablePrefix: sys_\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n\nspring:\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090','6f173937b704b23cc4860338937bfba7','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','代码生成器配置',NULL,NULL,'yaml',NULL,''),(18,'database-prod.yml','DEFAULT_GROUP','spring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','c0591a1c443136b0d815128319f77f72','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','数据库连接配置',NULL,NULL,'yaml',NULL,''),(19,'oauth2-service-prod.yml','DEFAULT_GROUP','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we_master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  #application:\n  #  name: oauth2-service','cc85dedd4f2c7557c3179921f1b204b5','2024-02-22 15:38:13','2024-02-28 16:26:51','nacos','192.168.31.10','','prod','OAuth2授权服务','','','yaml','',''),(20,'validator-service-prod.yml','DEFAULT_GROUP','server:\n  port: 8081\nspring:\n  messages:\n    # 国际化资源文件路径\n    basename: i18n/messages\n  application:\n    name: validator-service\n# 验证码相关配置\ncaptcha:\n  captcha-type: char # 验证码类型  math/char','49f36bc1c5aac2bd5ef07551f713c5c7','2024-02-22 15:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','','prod','验证器配置：短信验证、验证码等',NULL,NULL,'yaml',NULL,'');
/*!40000 ALTER TABLE `config_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_aggr`
--

DROP TABLE IF EXISTS `config_info_aggr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_aggr` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `datum_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'datum_id',
  `content` longtext COLLATE utf8mb3_bin NOT NULL COMMENT '内容',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `app_name` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfoaggr_datagrouptenantdatum` (`data_id`,`group_id`,`tenant_id`,`datum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='增加租户字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_aggr`
--

LOCK TABLES `config_info_aggr` WRITE;
/*!40000 ALTER TABLE `config_info_aggr` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_aggr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_beta`
--

DROP TABLE IF EXISTS `config_info_beta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_beta` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `app_name` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `beta_ips` varchar(1024) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'betaIps',
  `md5` varchar(32) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  `encrypted_data_key` text COLLATE utf8mb3_bin NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfobeta_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info_beta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_beta`
--

LOCK TABLES `config_info_beta` WRITE;
/*!40000 ALTER TABLE `config_info_beta` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_beta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_tag`
--

DROP TABLE IF EXISTS `config_info_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_tag` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `tag_id` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'tag_id',
  `app_name` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfotag_datagrouptenanttag` (`data_id`,`group_id`,`tenant_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info_tag';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_tag`
--

LOCK TABLES `config_info_tag` WRITE;
/*!40000 ALTER TABLE `config_info_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_tags_relation`
--

DROP TABLE IF EXISTS `config_tags_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_tags_relation` (
  `id` bigint NOT NULL COMMENT 'id',
  `tag_name` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'tag_name',
  `tag_type` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'tag_type',
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `nid` bigint NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nid`),
  UNIQUE KEY `uk_configtagrelation_configidtag` (`id`,`tag_name`,`tag_type`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_tag_relation';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_tags_relation`
--

LOCK TABLES `config_tags_relation` WRITE;
/*!40000 ALTER TABLE `config_tags_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_tags_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_capacity`
--

DROP TABLE IF EXISTS `group_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_capacity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL DEFAULT '' COMMENT 'Group ID，空字符表示整个集群',
  `quota` int unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数，，0表示使用默认值',
  `max_aggr_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='集群、各Group容量信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_capacity`
--

LOCK TABLES `group_capacity` WRITE;
/*!40000 ALTER TABLE `group_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `his_config_info`
--

DROP TABLE IF EXISTS `his_config_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `his_config_info` (
  `id` bigint unsigned NOT NULL,
  `nid` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) COLLATE utf8mb3_bin NOT NULL,
  `group_id` varchar(128) COLLATE utf8mb3_bin NOT NULL,
  `app_name` varchar(128) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext COLLATE utf8mb3_bin NOT NULL,
  `md5` varchar(32) COLLATE utf8mb3_bin DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `src_user` text COLLATE utf8mb3_bin,
  `src_ip` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `op_type` char(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  `encrypted_data_key` text COLLATE utf8mb3_bin NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`nid`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_gmt_modified` (`gmt_modified`),
  KEY `idx_did` (`data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='多租户改造';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `his_config_info`
--

LOCK TABLES `his_config_info` WRITE;
/*!40000 ALTER TABLE `his_config_info` DISABLE KEYS */;
INSERT INTO `his_config_info` (`id`, `nid`, `data_id`, `group_id`, `app_name`, `content`, `md5`, `gmt_create`, `gmt_modified`, `src_user`, `src_ip`, `op_type`, `tenant_id`, `encrypted_data_key`) VALUES (0,1,'auth-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8081\nspring:\n  messages:\n    # 国际化资源文件路径\n    basename: i18n/messages\n  application:\n    name: auth-service\n# 验证码相关配置\ncaptcha:\n  captcha-type: char # 验证码类型  math/char','4d3741d3123617d52492fcbd12d9ef0d','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,2,'common-prod.yml','DEFAULT_GROUP','','spring:\n  cloud:\n    nacos:\n      discovery:\n        server-addr: 192.168.1.5:8848\n  data:\n    redis:\n      host: 192.168.1.5\n  output:\n    ansi:\n      enabled: always\n  logging:\n    pattern:\n      level=%5p [${spring.application.name:},%X{traceId:-},%X{spanId:-}]\n    level:\n      org:\n        springframework:\n          web:\n            servlet:\n              DispatcherServlet: DEBUG\n\nmanagement:\n  endpoints:\n    web:\n      exposure:\n        include: \"*\"\n  endpoint:\n    health:\n      show-details: ALWAYS\n  tracing:\n    sampling:\n      probability: 1.0\n  metrics:\n    distribution:\n      percentiles-histogram:\n        greeting: true\n        http:\n          server:\n            requests: true','0054d93c1223ac13374b7865b9505af2','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,3,'monitoring-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 7001\nspring:\n  application:\n    name: monitoring-service','91f2f45e350042e89bc098200bdacf38','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,4,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','6ea5c45bf87e7cbeb3da3a862a39e4b4','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,5,'gateway-prod.yml','DEFAULT_GROUP','','server:\n  port: 8080\nspring:\n  application:\n    name: gateway\n\n  cloud:\n    gateway:\n      default-filters:\n      - AddResponseHeader=X-Response-Default-Foo, Default-Bar\n      routes:\n      - id: auth_service\n        uri: lb://auth-service\n        predicates:\n        - Path=/auth/**\n        filters:\n        - StripPrefix=1\n      - id: system_service\n        uri: lb://system-service\n        predicates:\n          - Path=/system/**\n      - id: demo-service\n        uri: lb://demo-service\n        predicates:\n          - Path=/demo/**\n        filters:\n        - StripPrefix=1\n      - id: oauth2-service\n        uri: lb://oauth2-service\n        predicates:\n          - Path=/oauth2/**\n        filters:\n        - StripPrefix=1\n\n\n\nsecurity:\n    xss:\n      enabled: true','df6fb9c4728841e27729bfe39a4f078e','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,6,'demo-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8083\nspring:\n  application:\n    name: demo-service\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n  #security:\n  #  oauth2:\n  #    resourceserver:\n  #      jwt:\n  #        issuer-uri: lb://oatuh2-server','48f5fd4d12023da34ea639221a306545','2024-02-22 23:36:46','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,7,'oatuh2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','7068c455b6fccace17be6bbc8ff90a6b','2024-02-22 23:36:47','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,8,'sentinel-rules-gateway-prod','DEFAULT_GROUP','','[\n    {\n        \"resource\": \"auth_service\",\n        \"count\": 1,\n        \"intervalSec\": 5,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    },\n	{\n        \"resource\": \"demo-service\",\n        \"count\": 1000,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    }\n]','1f626962e3574f6a56d1c8787634c30b','2024-02-22 23:36:47','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,9,'generator-service-prod.yml','DEFAULT_GROUP','','gen:\n  author: wm\n  packageName: org.wm.system\n  autoRemovePre: false\n  tablePrefix: sys_\nserver:\n  port: 9000','f26eb6515d922293ac8e1bdde9c090f5','2024-02-22 23:36:47','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(0,10,'database-prod.yml','DEFAULT_GROUP','','spring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','c0591a1c443136b0d815128319f77f72','2024-02-22 23:36:47','2024-02-22 15:36:47',NULL,'192.168.31.10','I','prod',''),(1,11,'auth-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8081\nspring:\n  messages:\n    # 国际化资源文件路径\n    basename: i18n/messages\n  application:\n    name: auth-service\n# 验证码相关配置\ncaptcha:\n  captcha-type: char # 验证码类型  math/char','4d3741d3123617d52492fcbd12d9ef0d','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(2,12,'common-prod.yml','DEFAULT_GROUP','','spring:\n  cloud:\n    nacos:\n      discovery:\n        server-addr: 192.168.1.5:8848\n  data:\n    redis:\n      host: 192.168.1.5\n  output:\n    ansi:\n      enabled: always\n  logging:\n    pattern:\n      level=%5p [${spring.application.name:},%X{traceId:-},%X{spanId:-}]\n    level:\n      org:\n        springframework:\n          web:\n            servlet:\n              DispatcherServlet: DEBUG\n\nmanagement:\n  endpoints:\n    web:\n      exposure:\n        include: \"*\"\n  endpoint:\n    health:\n      show-details: ALWAYS\n  tracing:\n    sampling:\n      probability: 1.0\n  metrics:\n    distribution:\n      percentiles-histogram:\n        greeting: true\n        http:\n          server:\n            requests: true','0054d93c1223ac13374b7865b9505af2','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(3,13,'monitoring-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 7001\nspring:\n  application:\n    name: monitoring-service','91f2f45e350042e89bc098200bdacf38','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(4,14,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','6ea5c45bf87e7cbeb3da3a862a39e4b4','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(5,15,'gateway-prod.yml','DEFAULT_GROUP','','server:\n  port: 8080\nspring:\n  application:\n    name: gateway\n\n  cloud:\n    gateway:\n      default-filters:\n      - AddResponseHeader=X-Response-Default-Foo, Default-Bar\n      routes:\n      - id: auth_service\n        uri: lb://auth-service\n        predicates:\n        - Path=/auth/**\n        filters:\n        - StripPrefix=1\n      - id: system_service\n        uri: lb://system-service\n        predicates:\n          - Path=/system/**\n      - id: demo-service\n        uri: lb://demo-service\n        predicates:\n          - Path=/demo/**\n        filters:\n        - StripPrefix=1\n      - id: oauth2-service\n        uri: lb://oauth2-service\n        predicates:\n          - Path=/oauth2/**\n        filters:\n        - StripPrefix=1\n\n\n\nsecurity:\n    xss:\n      enabled: true','df6fb9c4728841e27729bfe39a4f078e','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(6,16,'demo-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8083\nspring:\n  application:\n    name: demo-service\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n  #security:\n  #  oauth2:\n  #    resourceserver:\n  #      jwt:\n  #        issuer-uri: lb://oatuh2-server','48f5fd4d12023da34ea639221a306545','2024-02-22 23:37:45','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(7,17,'oatuh2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','7068c455b6fccace17be6bbc8ff90a6b','2024-02-22 23:37:46','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(8,18,'sentinel-rules-gateway-prod','DEFAULT_GROUP','','[\n    {\n        \"resource\": \"auth_service\",\n        \"count\": 1,\n        \"intervalSec\": 5,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    },\n	{\n        \"resource\": \"demo-service\",\n        \"count\": 1000,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    }\n]','1f626962e3574f6a56d1c8787634c30b','2024-02-22 23:37:46','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(9,19,'generator-service-prod.yml','DEFAULT_GROUP','','gen:\n  author: wm\n  packageName: org.wm.system\n  autoRemovePre: false\n  tablePrefix: sys_\nserver:\n  port: 9000','f26eb6515d922293ac8e1bdde9c090f5','2024-02-22 23:37:46','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(10,20,'database-prod.yml','DEFAULT_GROUP','','spring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','c0591a1c443136b0d815128319f77f72','2024-02-22 23:37:46','2024-02-22 15:37:46',NULL,'192.168.31.10','D','prod',''),(0,21,'common-prod.yml','DEFAULT_GROUP','','spring:\n  cloud:\n    nacos:\n      discovery:\n        server-addr: 192.168.31.160:8848\n  data:\n    redis:\n      host: 192.168.31.160\n  output:\n    ansi:\n      enabled: always\n  logging:\n    pattern:\n      level=%5p [${spring.application.name:},%X{traceId:-},%X{spanId:-}]\n    level:\n      org:\n        springframework:\n          web:\n            servlet:\n              DispatcherServlet: DEBUG\n\nmanagement:\n  endpoints:\n    web:\n      exposure:\n        include: \"*\"\n  endpoint:\n    health:\n      show-details: ALWAYS\n  tracing:\n    sampling:\n      probability: 1.0\n  metrics:\n    distribution:\n      percentiles-histogram:\n        greeting: true\n        http:\n          server:\n            requests: true\ntest: 123            ','cf27e833c3e42f00d550b9a2423dbb05','2024-02-22 23:38:12','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,22,'monitoring-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 7001\nspring:\n  application:\n    name: monitoring-service','91f2f45e350042e89bc098200bdacf38','2024-02-22 23:38:12','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,23,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.160:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','ff805b5dd9e24c21675b7b764b226751','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,24,'gateway-prod.yml','DEFAULT_GROUP','','server:\n  port: 8080\nspring:\n  application:\n    name: gateway\n\n  cloud:\n    gateway:\n      default-filters:\n      - AddResponseHeader=X-Response-Default-Foo, Default-Bar\n      routes:\n      - id: validator-service\n        uri: lb://validator-service\n        predicates:\n        - Path=/validator/**\n        filters:\n        - StripPrefix=1\n      - id: system_service\n        uri: lb://system-service\n        predicates:\n          - Path=/system/**\n      - id: demo-service\n        uri: lb://demo-service\n        predicates:\n          - Path=/demo/**\n        filters:\n        - StripPrefix=1\n      - id: oauth2-service\n        uri: lb://oauth2-service\n        predicates:\n          - Path=/oauth2/**\n        #filters:\n        #- StripPrefix=1\n\n\n\nsecurity:\n    xss:\n      enabled: true','840361dd18bebe67a1c17104366bb55f','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,25,'demo-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8083\nspring:\n  application:\n    name: demo-service\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n  #security:\n  #  oauth2:\n  #    resourceserver:\n  #      jwt:\n  #        issuer-uri: lb://oatuh2-server','48f5fd4d12023da34ea639221a306545','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,26,'sentinel-rules-gateway-prod','DEFAULT_GROUP','','[\n    {\n        \"resource\": \"auth_service\",\n        \"count\": 1,\n        \"intervalSec\": 5,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    },\n	{\n        \"resource\": \"demo-service\",\n        \"count\": 1000,\n        \"grade\": 1,\n        \"limitApp\": \"default\",\n        \"strategy\": 0,\n        \"controlBehavior\": 0\n    }\n]','1f626962e3574f6a56d1c8787634c30b','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,27,'generator-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 9000\ngen:\n  author: wm\n  packageName: org.wm.generator\n  autoRemovePre: false\n  tablePrefix: sys_\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret\n\nspring:\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090','6f173937b704b23cc4860338937bfba7','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,28,'database-prod.yml','DEFAULT_GROUP','','spring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.1.5:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1','c0591a1c443136b0d815128319f77f72','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,29,'oauth2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.160:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  #application:\n  #  name: oauth2-service','3785a8f18c4a9411b4d6676a0d812bf1','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(0,30,'validator-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8081\nspring:\n  messages:\n    # 国际化资源文件路径\n    basename: i18n/messages\n  application:\n    name: validator-service\n# 验证码相关配置\ncaptcha:\n  captcha-type: char # 验证码类型  math/char','49f36bc1c5aac2bd5ef07551f713c5c7','2024-02-22 23:38:13','2024-02-22 15:38:13',NULL,'192.168.31.10','I','prod',''),(11,31,'common-prod.yml','DEFAULT_GROUP','','spring:\n  cloud:\n    nacos:\n      discovery:\n        server-addr: 192.168.31.160:8848\n  data:\n    redis:\n      host: 192.168.31.160\n  output:\n    ansi:\n      enabled: always\n  logging:\n    pattern:\n      level=%5p [${spring.application.name:},%X{traceId:-},%X{spanId:-}]\n    level:\n      org:\n        springframework:\n          web:\n            servlet:\n              DispatcherServlet: DEBUG\n\nmanagement:\n  endpoints:\n    web:\n      exposure:\n        include: \"*\"\n  endpoint:\n    health:\n      show-details: ALWAYS\n  tracing:\n    sampling:\n      probability: 1.0\n  metrics:\n    distribution:\n      percentiles-histogram:\n        greeting: true\n        http:\n          server:\n            requests: true\ntest: 123            ','cf27e833c3e42f00d550b9a2423dbb05','2024-02-28 23:15:05','2024-02-28 15:15:06','nacos','192.168.31.10','U','prod',''),(13,32,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.160:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','ff805b5dd9e24c21675b7b764b226751','2024-02-28 23:16:08','2024-02-28 15:16:09','nacos','192.168.31.10','U','prod',''),(13,33,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','fdb24138aee3d3cd6a7830ccf95c8297','2024-02-28 23:16:51','2024-02-28 15:16:51','nacos','192.168.31.10','U','prod',''),(19,34,'oauth2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.160:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  #application:\n  #  name: oauth2-service','3785a8f18c4a9411b4d6676a0d812bf1','2024-02-28 23:17:56','2024-02-28 15:17:57','nacos','192.168.31.10','U','prod',''),(13,35,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','fdb24138aee3d3cd6a7830ccf95c8297','2024-02-29 00:24:59','2024-02-28 16:24:59','nacos','192.168.31.10','U','prod',''),(13,36,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','9b8ecc0eae8b2760ad61a4fec6a9349b','2024-02-29 00:25:28','2024-02-28 16:25:29','nacos','192.168.31.10','U','prod',''),(19,37,'oauth2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.25:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  #application:\n  #  name: oauth2-service','06bd274468e4893f4a5619d89c1d4ca1','2024-02-29 00:26:18','2024-02-28 16:26:19','nacos','192.168.31.10','U','prod',''),(19,38,'oauth2-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8090\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  #application:\n  #  name: oauth2-service','69434fd3e5c5c12ae7ec38acbb1b28b1','2024-02-29 00:26:51','2024-02-28 16:26:51','nacos','192.168.31.10','U','prod',''),(13,39,'system-service-prod.yml','DEFAULT_GROUP','','server:\n  port: 8082\n\n\nmybatis:\n  type-aliases-package: org.wm.system.entity\n  mapper-locations: classpath:mapper/**/*.xml\n  # configLocation: classpath:mybatis/mybatis-config.xml\n\n\nspring:\n  datasource:\n    type: com.zaxxer.hikari.HikariDataSource\n    driver-class-name: com.mysql.cj.jdbc.Driver\n    url: jdbc:mysql://192.168.31.10:3306/we-master?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8\n    username: root\n    password: 123456root\n    hikari:\n      maximum-pool-size: 10\n      max-lifetime: 20\n      connection-timeout: 60000\n      idle-timeout: 600000\n      connection-test-query: select 1\n  application:\n    name: system-service\n  security:\n    oauth2:\n      resourceserver:\n        jwt:\n          issuer-uri: http://localhost:8090\n# 验证 opaque token时使用\noauth2:\n  client-id: messaging-client-opaque\n  client-secret: secret','fdb24138aee3d3cd6a7830ccf95c8297','2024-02-29 00:27:07','2024-02-28 16:27:08','nacos','192.168.31.10','U','prod','');
/*!40000 ALTER TABLE `his_config_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `role` varchar(50) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `action` varchar(8) NOT NULL,
  UNIQUE KEY `uk_role_permission` (`role`,`resource`,`action`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  UNIQUE KEY `idx_user_role` (`username`,`role`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`username`, `role`) VALUES ('nacos','ROLE_ADMIN');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_capacity`
--

DROP TABLE IF EXISTS `tenant_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_capacity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_id` varchar(128) COLLATE utf8mb3_bin NOT NULL DEFAULT '' COMMENT 'Tenant ID',
  `quota` int unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数',
  `max_aggr_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='租户容量信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_capacity`
--

LOCK TABLES `tenant_capacity` WRITE;
/*!40000 ALTER TABLE `tenant_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_info`
--

DROP TABLE IF EXISTS `tenant_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) COLLATE utf8mb3_bin NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_info_kptenantid` (`kp`,`tenant_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='tenant_info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_info`
--

LOCK TABLES `tenant_info` WRITE;
/*!40000 ALTER TABLE `tenant_info` DISABLE KEYS */;
INSERT INTO `tenant_info` (`id`, `kp`, `tenant_id`, `tenant_name`, `tenant_desc`, `create_source`, `gmt_create`, `gmt_modified`) VALUES (1,'1','prod','prod','测试命名空间','nacos',1708616158075,1708616158075);
/*!40000 ALTER TABLE `tenant_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`, `password`, `enabled`) VALUES ('nacos','$2a$10$EuWPZHzz32dJN7jexM34MOeYirDdFAZm2kuWj7VEOJhhZkDrxfvUu',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-10 19:34:36
